package com.example.carromaim

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.net.Uri
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import android.webkit.WebView
import android.webkit.WebViewClient
import com.airbnb.lottie.LottieAnimationView
import kotlin.math.atan2
import kotlin.math.sqrt
import kotlin.math.abs

class MainActivity : Activity() {
    private lateinit var board: BoardView
    private lateinit var status: TextView
    private val pickPhoto = 42
    private var darkMode = false
    private var themeIndex = 0
    private var glowEnabled = true

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(12, 8, 12, 8)
            setBackgroundColor(if (darkMode) Color.rgb(18, 20, 28) else Color.rgb(247, 244, 236))
        }
        val title = TextView(this).apply {
            text = "✦ CARROM AIM STUDIO ✦"
            textSize = 22f
            setTextColor(Color.rgb(50, 40, 30))
            gravity = Gravity.CENTER
            setPadding(4, 8, 4, 10)
            alpha = 0f
            translationY = -18f
        }
        status = TextView(this).apply {
            text = "Set striker, add multiple coins, then set a pocket. Tap Suggest Best Shot."
            textSize = 13f
            setTextColor(Color.DKGRAY)
            setPadding(4, 2, 4, 6)
        }
        board = BoardView(this) { status.text = it }

        fun makeRow(): LinearLayout = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        fun addButton(row: LinearLayout, label: String, action: () -> Unit) {
            val button = Button(this).apply {
                text = label
                textSize = 11f
                setPadding(2, 0, 2, 0)
                setOnClickListener { action() }
            }
            row.addView(button, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        }

        val row1 = makeRow()
        addButton(row1, "Set Striker") { board.setMode(TapMode.STRIKER) }
        addButton(row1, "Add Coin") { board.setMode(TapMode.COIN) }
        addButton(row1, "Set Pocket") { board.setMode(TapMode.POCKET) }

        val row2 = makeRow()
        addButton(row2, "Suggest Best Shot") { status.text = board.suggestBestShot() }
        addButton(row2, "Undo") { board.undoPoint() }
        addButton(row2, "Reset") { board.resetPoints() }

        val row3 = makeRow()
        addButton(row3, "Choose Photo") {
            val intent = Intent(Intent.ACTION_GET_CONTENT).apply { type = "image/*" }
            startActivityForResult(Intent.createChooser(intent, "Choose a carrom board photo"), pickPhoto)
        }
        addButton(row3, "Practice Board") { board.clearPhoto(); board.resetPoints() }

        val row4 = makeRow()
        addButton(row4, "Dark / Light") {
            darkMode = !darkMode
            content.setBackgroundColor(if (darkMode) Color.rgb(18, 20, 28) else Color.rgb(247, 244, 236))
            title.setTextColor(if (darkMode) Color.WHITE else Color.rgb(50, 40, 30))
            status.setTextColor(if (darkMode) Color.rgb(225, 230, 240) else Color.DKGRAY)
            noteColorRefresh(content, darkMode)
            board.setDarkMode(darkMode)
            status.text = if (darkMode) "Dark screen enabled. Practice mode only." else "Light screen enabled. Practice mode only."
        }
        addButton(row4, "Color Theme") {
            themeIndex = (themeIndex + 1) % 4
            board.setTheme(themeIndex)
            status.text = listOf("Blue theme", "Neon theme", "Amber theme", "Violet theme")[themeIndex] + " enabled."
        }
        addButton(row4, "Glow On / Off") {
            glowEnabled = !glowEnabled
            board.setGlow(glowEnabled)
            status.text = if (glowEnabled) "Glow lighting enabled." else "Glow lighting disabled."
        }

        val introAnimation = LottieAnimationView(this).apply {
            setAnimation("animations/intro_glow.json")
            repeatCount = 0
            scaleType = android.widget.ImageView.ScaleType.FIT_CENTER
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, (72 * resources.displayMetrics.density).toInt())
            playAnimation()
        }

        content.addView(introAnimation)
        content.addView(title)
        content.addView(status)
        content.addView(board, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        content.addView(row1)
        content.addView(row2)
        content.addView(row3)
        content.addView(row4)

        val row5 = makeRow()
        addButton(row5, "Shot GIF Animations") { showShotGifs() }
        addButton(row5, "Open Carrom Pool") { openCarromPool() }
        content.addView(row5)

        val row6 = makeRow()
        addButton(row6, "Pocket Light Demo") {
            board.setGlow(true)
            glowEnabled = true
            status.text = "Pulsing pocket lighting is active on this practice board."
            Toast.makeText(this, "Practice pocket lights enabled", Toast.LENGTH_SHORT).show()
        }
        addButton(row6, "Reset Theme") {
            themeIndex = 0
            darkMode = false
            glowEnabled = true
            content.setBackgroundColor(Color.rgb(247, 244, 236))
            title.setTextColor(Color.rgb(50, 40, 30))
            status.setTextColor(Color.DKGRAY)
            board.setDarkMode(false)
            board.setTheme(0)
            board.setGlow(true)
            status.text = "Default blue theme restored."
        }
        content.addView(row6)

        val note = TextView(this).apply {
            text = "Standalone practice tool • estimates only • no connection to Carrom Pool"
            textSize = 11f
            setTextColor(Color.GRAY)
            setPadding(4, 5, 4, 0)
        }
        content.addView(note)
        setContentView(content)
        title.animate().alpha(1f).translationY(0f).setDuration(650).start()
        content.post {
            for (i in 0 until content.childCount) {
                val child = content.getChildAt(i)
                child.alpha = 0f
                child.animate().alpha(1f).setStartDelay((i * 45L).coerceAtMost(500L)).setDuration(300).start()
            }
            title.alpha = 1f
        }
        board.setDarkMode(darkMode)
        board.setTheme(themeIndex)
        board.setGlow(glowEnabled)
    }


    private fun openCarromPool() {
        // Opens the official game if installed; otherwise opens its Play Store listing.
        val packageName = "com.miniclip.carrompool"
        val launch = packageManager.getLaunchIntentForPackage(packageName)
        try {
            if (launch != null) {
                startActivity(launch)
            } else {
                val market = Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$packageName"))
                try { startActivity(market) }
                catch (_: Exception) { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=$packageName"))) }
            }
        } catch (_: Exception) {
            Toast.makeText(this, "Carrom Pool could not be opened on this device.", Toast.LENGTH_LONG).show()
        }
    }

    private fun showShotGifs() {
        val names = arrayOf(
            "Aim line", "Straight shot", "Left cut", "Right cut", "Bank left", "Bank right",
            "Rebound angle", "Choose pocket", "Soft power", "Medium power", "Strong power",
            "Multiple targets", "Avoid blocker", "Practice setup"
        )
        val files = arrayOf(
            "aim_line.gif", "straight_shot.gif", "cut_left.gif", "cut_right.gif", "bank_left.gif", "bank_right.gif",
            "rebound_angle.gif", "choose_pocket.gif", "soft_power.gif", "medium_power.gif", "strong_power.gif",
            "multiple_targets.gif", "avoid_blocker.gif", "practice_setup.gif"
        )
        AlertDialog.Builder(this)
            .setTitle("Animated Shot Guide")
            .setItems(names) { _, which ->
                val web = WebView(this).apply {
                    setBackgroundColor(Color.rgb(18, 20, 28))
                    settings.javaScriptEnabled = false
                    loadDataWithBaseURL("file:///android_asset/gifs/", """
                        <html><body style='margin:0;background:#12141c;color:#fff;font-family:sans-serif;text-align:center'>
                        <h3>${names[which]}</h3><img src='${files[which]}' style='width:96%;height:auto;max-height:70vh;object-fit:contain'/>
                        <p>Practice animation only</p></body></html>
                    """.trimIndent(), "text/html", "UTF-8", null)
                }
                AlertDialog.Builder(this).setTitle(names[which]).setView(web)
                    .setPositiveButton("Close", null).show()
            }
            .setNegativeButton("Close", null)
            .show()
    }

    private fun noteColorRefresh(content: LinearLayout, dark: Boolean) {
        // Update labels in the current screen without changing the practice logic.
        for (i in 0 until content.childCount) {
            val child = content.getChildAt(i)
            if (child is TextView && child.text.toString().startsWith("Standalone practice tool")) {
                child.setTextColor(if (dark) Color.rgb(170, 180, 195) else Color.GRAY)
            }
        }
    }

    @Deprecated("Uses the compatible gallery picker for a simple standalone sample")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == pickPhoto && resultCode == RESULT_OK) {
            val uri: Uri = data?.data ?: return
            try {
                contentResolver.openInputStream(uri).use { stream ->
                    val bitmap = BitmapFactory.decodeStream(stream)
                    if (bitmap != null) board.setPhoto(bitmap)
                    else Toast.makeText(this, "Could not open this image", Toast.LENGTH_SHORT).show()
                }
            } catch (_: Exception) {
                Toast.makeText(this, "Could not open this image", Toast.LENGTH_SHORT).show()
            }
        }
    }
}

private data class PointN(val x: Float, val y: Float)
private enum class TapMode { STRIKER, COIN, POCKET }

private class BoardView(context: android.content.Context, val onStatus: (String) -> Unit) : View(context) {
    private var striker: PointN? = null
    private val coins = mutableListOf<PointN>()
    private var pocket: PointN? = null
    private var bestCoinIndex: Int = -1
    private var mode = TapMode.STRIKER
    private var photo: Bitmap? = null
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(30, 130, 220); strokeWidth = 4f; style = Paint.Style.STROKE }
    private val guidePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(240, 120, 35); strokeWidth = 3f; style = Paint.Style.STROKE }
    private val bestPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(30, 220, 120); strokeWidth = 5f; style = Paint.Style.STROKE }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(40, 35, 30); textSize = 28f; typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL) }
    private var darkMode = false
    private var themeIndex = 0
    private var glowEnabled = true
    private val animationStart = android.os.SystemClock.uptimeMillis()

    fun setDarkMode(enabled: Boolean) { darkMode = enabled; invalidate() }
    fun setTheme(index: Int) {
        themeIndex = index
        val colors = listOf(Color.rgb(40, 150, 255), Color.rgb(0, 235, 190), Color.rgb(255, 175, 55), Color.rgb(190, 105, 255))
        linePaint.color = colors[index.coerceIn(0, colors.lastIndex)]
        invalidate()
    }
    fun setGlow(enabled: Boolean) { glowEnabled = enabled; setLayerType(if (enabled) View.LAYER_TYPE_SOFTWARE else View.LAYER_TYPE_HARDWARE, null); invalidate() }

    fun setMode(newMode: TapMode) {
        mode = newMode
        onStatus(when (mode) {
            TapMode.STRIKER -> "Tap the striker position on the board."
            TapMode.COIN -> "Tap each target coin. You can add several coins."
            TapMode.POCKET -> "Tap the pocket you want to aim for."
        })
    }

    fun setPhoto(bitmap: Bitmap) {
        photo = bitmap
        resetPoints()
        onStatus("Photo loaded. Set Striker → Add Coin (one or more) → Set Pocket → Suggest Best Shot.")
    }

    fun clearPhoto() { photo = null; invalidate() }

    fun resetPoints() {
        striker = null; coins.clear(); pocket = null; bestCoinIndex = -1
        invalidate(); setMode(TapMode.STRIKER)
    }

    fun undoPoint() {
        when {
            pocket != null -> pocket = null
            coins.isNotEmpty() -> coins.removeAt(coins.lastIndex)
            striker != null -> striker = null
        }
        bestCoinIndex = -1
        invalidate()
        onStatus("Undo complete. Striker: ${if (striker == null) "not set" else "set"}; coins: ${coins.size}; pocket: ${if (pocket == null) "not set" else "set"}.")
    }

    fun suggestBestShot(): String {
        val s = striker ?: return "First tap Set Striker and mark the striker position."
        val p = pocket ?: return "Set a pocket first. Add one or more target coins, then tap Set Pocket."
        if (coins.isEmpty()) return "Add at least one target coin first."
        var bestScore = Float.MAX_VALUE
        var bestIndex = -1
        coins.forEachIndexed { index, coin ->
            val d1 = distance(s, coin)
            val d2 = distance(coin, p)
            val incoming = atan2((coin.y - s.y).toDouble(), (coin.x - s.x).toDouble())
            val outgoing = atan2((p.y - coin.y).toDouble(), (p.x - coin.x).toDouble())
            var angle = abs(Math.toDegrees(outgoing - incoming)).toFloat()
            if (angle > 180f) angle = 360f - angle
            // Heuristic only: prefer shorter paths and avoid extremely sharp turns.
            val score = d1 + d2 + (angle / 180f) * 0.22f
            if (score < bestScore) { bestScore = score; bestIndex = index }
        }
        bestCoinIndex = bestIndex
        invalidate()
        val chosen = coins[bestIndex]
        val angle = angleAt(s, chosen, p).toInt()
        return "Best estimate: Coin ${bestIndex + 1} • path score ${"%.2f".format(bestScore)} • direction change about ${angle}°. Green = suggested shot. Estimate only; verify visually."
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val area = RectF(8f, 8f, width - 8f, height - 8f)
        val bmp = photo
        if (bmp != null) {
            val scale = minOf(area.width() / bmp.width, area.height() / bmp.height)
            val w = bmp.width * scale; val h = bmp.height * scale
            val dst = RectF(area.centerX() - w / 2, area.centerY() - h / 2, area.centerX() + w / 2, area.centerY() + h / 2)
            canvas.drawBitmap(bmp, null, dst, paint)
        } else drawPracticeBoard(canvas, area)

        val s = striker
        val p = pocket
        if (s != null) {
            coins.forEachIndexed { index, coin ->
                val sp = toScreen(s, area, bmp); val cp = toScreen(coin, area, bmp)
                val targetPaint = if (index == bestCoinIndex && p != null) bestPaint else linePaint
                if (glowEnabled) {
                    targetPaint.setShadowLayer(12f, 0f, 0f, targetPaint.color)
                    canvas.drawLine(sp.first, sp.second, cp.first, cp.second, targetPaint)
                    targetPaint.clearShadowLayer()
                } else canvas.drawLine(sp.first, sp.second, cp.first, cp.second, targetPaint)
                if (index == bestCoinIndex && p != null) {
                    val pp = toScreen(p, area, bmp)
                    if (glowEnabled) {
                        bestPaint.setShadowLayer(15f, 0f, 0f, bestPaint.color)
                        canvas.drawLine(cp.first, cp.second, pp.first, pp.second, bestPaint)
                        bestPaint.clearShadowLayer()
                    } else canvas.drawLine(cp.first, cp.second, pp.first, pp.second, bestPaint)
                }
            }
        }
        striker?.let { drawPoint(canvas, toScreen(it, area, bmp), Color.rgb(20, 120, 240), "S") }
        coins.forEachIndexed { index, point ->
            drawPoint(canvas, toScreen(point, area, bmp), if (index == bestCoinIndex) Color.rgb(30, 165, 90) else Color.rgb(220, 70, 55), "C${index + 1}")
        }
        pocket?.let { drawPoint(canvas, toScreen(it, area, bmp), Color.rgb(240, 120, 35), "P") }
        if (glowEnabled) postInvalidateDelayed(55L)
    }

    private fun drawPoint(canvas: Canvas, p: Pair<Float, Float>, color: Int, label: String) {
        paint.color = color; paint.style = Paint.Style.FILL
        if (glowEnabled && label == "P") {
            val phase = ((android.os.SystemClock.uptimeMillis() - animationStart) % 1100L) / 1100f
            val pulse = 15f + 7f * (0.5f + 0.5f * kotlin.math.sin(phase * 2f * Math.PI).toFloat())
            paint.alpha = 90
            paint.setShadowLayer(18f, 0f, 0f, color)
            canvas.drawCircle(p.first, p.second, pulse, paint)
            paint.clearShadowLayer()
            paint.alpha = 255
        }
        canvas.drawCircle(p.first, p.second, 12f, paint)
        paint.color = Color.WHITE; canvas.drawCircle(p.first, p.second, 4f, paint)
        canvas.drawText(label, p.first + 13f, p.second - 10f, textPaint)
    }

    private fun drawPracticeBoard(canvas: Canvas, r: RectF) {
        paint.color = if (darkMode) Color.rgb(38, 42, 58) else Color.rgb(231, 190, 126); canvas.drawRoundRect(r, 24f, 24f, paint)
        val inset = r.width() * 0.09f
        val inner = RectF(r.left + inset, r.top + inset, r.right - inset, r.bottom - inset)
        paint.color = if (darkMode) Color.rgb(23, 27, 39) else Color.rgb(248, 225, 180); canvas.drawRect(inner, paint)
        paint.color = if (darkMode) Color.rgb(90, 120, 165) else Color.rgb(120, 70, 38); paint.style = Paint.Style.STROKE; paint.strokeWidth = 5f; canvas.drawRect(inner, paint); paint.style = Paint.Style.FILL
        val rad = r.width() * 0.045f
        val pockets = listOf(inner.left to inner.top, inner.right to inner.top, inner.left to inner.bottom, inner.right to inner.bottom)
        if (glowEnabled) {
            val phase = ((android.os.SystemClock.uptimeMillis() - animationStart) % 1100L) / 1100f
            val pulse = 1.2f + 0.25f * (0.5f + 0.5f * kotlin.math.sin(phase * 2f * Math.PI).toFloat())
            paint.color = listOf(Color.rgb(40, 150, 255), Color.rgb(0, 235, 190), Color.rgb(255, 175, 55), Color.rgb(190, 105, 255))[themeIndex.coerceIn(0, 3)]
            paint.alpha = 105
            pockets.forEach { canvas.drawCircle(it.first, it.second, rad * pulse, paint) }
            paint.alpha = 255
        }
        paint.color = Color.rgb(55, 35, 25); pockets.forEach { canvas.drawCircle(it.first, it.second, rad, paint) }
        paint.color = Color.rgb(190, 130, 75); paint.style = Paint.Style.STROKE; paint.strokeWidth = 3f
        canvas.drawCircle(inner.centerX(), inner.centerY(), r.width() * .12f, paint)
        canvas.drawCircle(inner.centerX(), inner.centerY(), r.width() * .055f, paint)
        paint.style = Paint.Style.FILL
        paint.color = Color.rgb(45, 45, 45); canvas.drawCircle(inner.centerX(), inner.centerY(), r.width() * .018f, paint)
        paint.color = Color.rgb(205, 40, 45); canvas.drawCircle(inner.centerX() + r.width() * .045f, inner.centerY() - r.width() * .02f, r.width() * .018f, paint)
        paint.color = Color.rgb(245, 240, 225); canvas.drawCircle(inner.centerX() - r.width() * .04f, inner.centerY() + r.width() * .03f, r.width() * .018f, paint)
        paint.color = Color.rgb(120, 70, 38); canvas.drawRoundRect(RectF(inner.left + inner.width()*.28f, inner.bottom - 28f, inner.right - inner.width()*.28f, inner.bottom - 12f), 8f, 8f, paint)
    }

    private fun toScreen(p: PointN, area: RectF, bmp: Bitmap?): Pair<Float, Float> {
        if (bmp == null) return (area.left + p.x * area.width()) to (area.top + p.y * area.height())
        val scale = minOf(area.width() / bmp.width, area.height() / bmp.height)
        val w = bmp.width * scale; val h = bmp.height * scale
        val left = area.centerX() - w / 2; val top = area.centerY() - h / 2
        return (left + p.x * w) to (top + p.y * h)
    }

    override fun onTouchEvent(event: android.view.MotionEvent): Boolean {
        if (event.action != android.view.MotionEvent.ACTION_UP) return true
        val area = RectF(8f, 8f, width - 8f, height - 8f)
        val bmp = photo
        val normalized: PointN
        if (bmp == null) {
            normalized = PointN(((event.x - area.left) / area.width()).coerceIn(0f, 1f), ((event.y - area.top) / area.height()).coerceIn(0f, 1f))
        } else {
            val scale = minOf(area.width() / bmp.width, area.height() / bmp.height)
            val w = bmp.width * scale; val h = bmp.height * scale
            val left = area.centerX() - w / 2; val top = area.centerY() - h / 2
            if (event.x < left || event.x > left + w || event.y < top || event.y > top + h) return true
            normalized = PointN(((event.x - left) / w).coerceIn(0f, 1f), ((event.y - top) / h).coerceIn(0f, 1f))
        }
        when (mode) {
            TapMode.STRIKER -> { striker = normalized; bestCoinIndex = -1; onStatus("Striker set. Tap Add Coin, then mark each target coin.") }
            TapMode.COIN -> { coins.add(normalized); bestCoinIndex = -1; onStatus("Coin ${coins.size} added. Add more coins or tap Set Pocket.") }
            TapMode.POCKET -> { pocket = normalized; bestCoinIndex = -1; onStatus("Pocket set. Tap Suggest Best Shot to compare the target coins.") }
        }
        invalidate()
        return true
    }

    private fun distance(a: PointN, b: PointN): Float {
        val dx = a.x - b.x; val dy = a.y - b.y
        return sqrt(dx * dx + dy * dy)
    }

    private fun angleAt(a: PointN, b: PointN, c: PointN): Double {
        val incoming = atan2((b.y - a.y).toDouble(), (b.x - a.x).toDouble())
        val outgoing = atan2((c.y - b.y).toDouble(), (c.x - b.x).toDouble())
        var angle = abs(Math.toDegrees(outgoing - incoming))
        if (angle > 180) angle = 360 - angle
        return angle
    }
}
