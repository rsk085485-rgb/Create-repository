# Carrom Aim Studio — Android source project (v1.1)

A standalone carrom practice companion. It does not modify Carrom Pool, inject into it, read its screen, or provide an in-game overlay/cheat.

## Features
- Animated opening header using the Lottie animation library
- Practice board with striker, multiple target coins, and pocket selection
- Best-shot estimate and path guide (heuristic only)
- Dark/light screen mode and four colour themes
- Glow lighting and pulsing pocket lights on the practice board
- 14 animated GIF shot guides in `app/src/main/assets/gifs/`
- Button to open Carrom Pool if installed, or its Play Store listing if not installed
- Choose a board photo for manual practice planning

## Libraries added
- AndroidX Core KTX 1.15.0
- AndroidX AppCompat 1.7.0
- Material Components 1.12.0
- Lottie Android 6.6.2 for the animated intro

Gradle downloads these dependencies during the build, so an internet connection is required for the first build.

## Build
On Android, upload the extracted project folders/files to a GitHub repository, then run the included workflow under **Actions**. Download the APK from the workflow's **Artifacts** section after a successful build.

This ZIP is source code, not an APK. A successful build has not been verified in this environment, and the final APK size depends on Android packaging and the selected libraries/assets; no exact 19 MB size is guaranteed.


## Included Android libraries

- AndroidX Core KTX 1.15.0
- AndroidX AppCompat 1.7.0
- Material Components 1.12.0
- Lottie Android 6.6.2 for JSON animations
- Kotlin Android Gradle plugin 2.0.21

These are declared as Gradle dependencies. They are downloaded by Gradle from Google's/Maven repositories during the build, so they are not stored as large JAR files inside this ZIP. An APK has not been built or tested in this environment.
